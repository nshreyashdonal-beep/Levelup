const instructors = [
  { name: "Riya Kapoor", subject: "UI/UX Design", distance: "1.8 km", lat: 22.738, lng: 75.865, initials: "RK", color: "#d68162" },
  { name: "Arjun Mehta", subject: "Photography", distance: "3.2 km", lat: 22.731, lng: 75.878, initials: "AM", color: "#587f72" },
  { name: "Neha Joshi", subject: "Spoken English", distance: "4.5 km", lat: 22.748, lng: 75.851, initials: "NJ", color: "#8b73a8" },
  { name: "Kabir Shah", subject: "Digital Marketing", distance: "6.1 km", lat: 22.715, lng: 75.884, initials: "KS", color: "#c48b45" },
  { name: "Meera Iyer", subject: "Classical Dance", distance: "8.4 km", lat: 22.759, lng: 75.893, initials: "MI", color: "#6893a0" },
  { name: "Dev Malhotra", subject: "Python Programming", distance: "11.7 km", lat: 22.704, lng: 75.843, initials: "DM", color: "#6d7eaf" }
];

const courses = [
  { title: "Design thinking for beginners", instructor: "Riya Kapoor", category: "DESIGN", price: "₹799", rating: "4.9", image: "https://images.unsplash.com/photo-1558655146-d09347e92766?auto=format&fit=crop&w=600&q=80" },
  { title: "Capture your city", instructor: "Arjun Mehta", category: "PHOTOGRAPHY", price: "₹599", rating: "4.8", image: "https://images.unsplash.com/photo-1452780212940-6f5c0d14d848?auto=format&fit=crop&w=600&q=80" },
  { title: "Speak with confidence", instructor: "Neha Joshi", category: "LANGUAGE", price: "₹499", rating: "4.9", image: "https://images.unsplash.com/photo-1546410531-bb4caa6b424d?auto=format&fit=crop&w=600&q=80" },
  { title: "Build your first website", instructor: "Dev Malhotra", category: "TECHNOLOGY", price: "₹999", rating: "4.7", image: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=600&q=80" }
];

const mapCenter = [22.735, 75.87];
const map = L.map("map", { zoomControl: false }).setView(mapCenter, 12);
L.control.zoom({ position: "bottomright" }).addTo(map);
L.tileLayer("https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png", {
  subdomains: "abcd",
  maxZoom: 20,
  attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> &copy; <a href="https://carto.com/attributions">CARTO</a>'
}).addTo(map);

const instructorIcon = L.divIcon({
  className: "custom-map-marker",
  html: '<span style="background:#1d6655">✦</span>',
  iconSize: [30, 30],
  iconAnchor: [15, 15]
});

const studentIcon = L.divIcon({
  className: "custom-map-marker",
  html: '<span style="background:#e98c69">●</span>',
  iconSize: [30, 30],
  iconAnchor: [15, 15]
});

instructors.forEach((instructor) => {
  L.marker([instructor.lat, instructor.lng], { icon: instructorIcon })
    .addTo(map)
    .bindPopup(`<strong>${instructor.name}</strong><br>${instructor.subject}<br><a href="#courses">View courses →</a>`);
});

function renderInstructorList() {
  const list = document.querySelector("#instructorList");
  list.innerHTML = instructors.map((instructor) => `
    <button class="instructor-item" type="button" data-lat="${instructor.lat}" data-lng="${instructor.lng}">
      <span class="instructor-avatar" style="background:${instructor.color}">${instructor.initials}</span>
      <span class="instructor-info">
        <strong>${instructor.name}</strong>
        <span>${instructor.subject}</span>
      </span>
      <span class="instructor-distance">${instructor.distance}</span>
    </button>
  `).join("");

  list.querySelectorAll(".instructor-item").forEach((item) => {
    item.addEventListener("click", () => {
      map.setView([Number(item.dataset.lat), Number(item.dataset.lng)], 14);
    });
  });
}

function renderCourses() {
  document.querySelector("#courseGrid").innerHTML = courses.map((course) => `
    <article class="course-card">
      <div class="course-image" style="background-image:url('${course.image}')">
        <span class="course-tag">${course.category}</span>
      </div>
      <div class="course-content">
        <h3>${course.title}</h3>
        <div class="course-meta"><span>By ${course.instructor}</span><span>★ ${course.rating}</span></div>
        <div class="course-price">${course.price} <span style="color:#718096;font-size:11px;font-weight:400">/ course</span></div>
      </div>
    </article>
  `).join("");
}

function locateStudent() {
  const message = document.querySelector("#locationMessage");
  const button = document.querySelector("#locateButton");
  button.disabled = true;
  button.innerHTML = "<span>⌖</span> Finding you…";

  if (!navigator.geolocation) {
    message.textContent = "Your browser does not support location. Showing the demo area instead.";
    button.disabled = false;
    button.innerHTML = "<span>⌖</span> Use my location";
    return;
  }

  navigator.geolocation.getCurrentPosition(
    (position) => {
      const userLocation = [position.coords.latitude, position.coords.longitude];
      map.setView(userLocation, 13);
      L.marker(userLocation, { icon: studentIcon }).addTo(map).bindPopup("<strong>You are here</strong>").openPopup();
      message.textContent = "Your location is on the map. Nearby instructors are ready to explore.";
      button.disabled = false;
      button.innerHTML = "<span>✓</span> Location found";
    },
    () => {
      message.textContent = "Location permission was not granted. Showing instructors around Indore instead.";
      button.disabled = false;
      button.innerHTML = "<span>⌖</span> Try again";
    }
  );
}

renderInstructorList();
renderCourses();
document.querySelector("#locateButton").addEventListener("click", locateStudent);
document.querySelector("#locateHeroButton").addEventListener("click", () => {
  document.querySelector("#instructors").scrollIntoView({ behavior: "smooth" });
  setTimeout(locateStudent, 500);
});
